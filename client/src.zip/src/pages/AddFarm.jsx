import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { addFarm } from "../services/farmService";

const AddFarm = () => {
  const navigate = useNavigate();

  // Get logged-in user
  const user = JSON.parse(localStorage.getItem("user"));

  const [formData, setFormData] = useState({
    farmer: user?.id || "",
    farmName: "",
    location: "",
    cropType: "",
    area: "",
    soilType: "",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const data = await addFarm(formData);

      alert(data.message);

      navigate("/farms");
    } catch (error) {
      console.error(error);

      alert(error.response?.data?.message || "Failed to add farm");
    }
  };

  return (
    <div className="container mt-5">
      <div className="card shadow p-4">

        <h2 className="text-center mb-4">
          🌱 Add New Farm
        </h2>

        <form onSubmit={handleSubmit}>

          <div className="mb-3">
            <label className="form-label">Farm Name</label>

            <input
              type="text"
              className="form-control"
              name="farmName"
              value={formData.farmName}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Location</label>

            <input
              type="text"
              className="form-control"
              name="location"
              value={formData.location}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Crop Type</label>

            <input
              type="text"
              className="form-control"
              name="cropType"
              value={formData.cropType}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Area (Acres)</label>

            <input
              type="number"
              className="form-control"
              name="area"
              value={formData.area}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-4">
            <label className="form-label">Soil Type</label>

            <input
              type="text"
              className="form-control"
              name="soilType"
              value={formData.soilType}
              onChange={handleChange}
              required
            />
          </div>

          <button className="btn btn-success w-100">
            Save Farm
          </button>

        </form>

      </div>
    </div>
  );
};

export default AddFarm;