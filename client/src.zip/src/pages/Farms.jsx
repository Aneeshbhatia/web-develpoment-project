import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getFarms, deleteFarm } from "../services/farmService";
import {
  MapPin,
  Sprout,
  Mountain,
  Ruler,
  User,
  Pencil,
  Trash2,
  Plus,
  Search,
  CloudSun,
} from "lucide-react";

const Farms = () => {
  const navigate = useNavigate();

  const [farms, setFarms] = useState([]);
  const [filteredFarms, setFilteredFarms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  // ==========================
  // Load Farms
  // ==========================
  const loadFarms = async () => {
    try {
      const response = await getFarms();

      if (response.success) {
        setFarms(response.farms);
        setFilteredFarms(response.farms);
      }
    } catch (error) {
      console.error(error);
      alert("Failed to load farms");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFarms();
  }, []);

  // ==========================
  // Search
  // ==========================
  useEffect(() => {
    const result = farms.filter(
      (farm) =>
        farm.farmName.toLowerCase().includes(search.toLowerCase()) ||
        farm.location.toLowerCase().includes(search.toLowerCase()) ||
        farm.cropType.toLowerCase().includes(search.toLowerCase())
    );

    setFilteredFarms(result);
  }, [search, farms]);

  // ==========================
  // Delete Farm
  // ==========================
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Delete this farm?"
    );

    if (!confirmDelete) return;

    try {
      const response = await deleteFarm(id);

      alert(response.message);

      loadFarms();
    } catch (error) {
      console.error(error);
      alert("Delete failed");
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen text-3xl font-bold text-green-700">
        Loading Farms...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">

      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-center mb-8 gap-4">

        <div>
          <h1 className="text-4xl font-bold text-green-700">
            🌾 My Farms
          </h1>

          <p className="text-gray-500 mt-2">
            Manage all your farms from one place.
          </p>
        </div>

        <button
          onClick={() => navigate("/add-farm")}
          className="flex items-center gap-2 bg-gradient-to-r from-green-600 to-emerald-500 text-white px-6 py-3 rounded-xl shadow-lg hover:scale-105 transition"
        >
          <Plus size={20} />
          Add Farm
        </button>

      </div>

      {/* Search */}
      <div className="relative mb-8">

        <Search
          size={20}
          className="absolute left-4 top-4 text-gray-400"
        />

        <input
          type="text"
          placeholder="Search by Farm, Crop or Location..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-white rounded-xl shadow p-4 pl-12 outline-none"
        />

      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">

        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-gray-500">
            Total Farms
          </h3>

          <p className="text-4xl font-bold text-green-700 mt-2">
            {farms.length}
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-gray-500">
            Total Area
          </h3>

          <p className="text-4xl font-bold text-blue-600 mt-2">
            {farms.reduce((sum, farm) => sum + farm.area, 0)} Acres
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-gray-500">
            Crop Types
          </h3>

          <p className="text-4xl font-bold text-yellow-600 mt-2">
            {new Set(farms.map((farm) => farm.cropType)).size}
          </p>
        </div>

      </div>

      {/* Empty */}
      {filteredFarms.length === 0 ? (
        <div className="bg-white rounded-3xl shadow-lg p-12 text-center">

          <div className="text-7xl">
            🌱
          </div>

          <h2 className="text-3xl font-bold mt-5">
            No Farms Found
          </h2>

          <p className="text-gray-500 mt-3">
            Add your first farm to begin.
          </p>

        </div>
      ) : (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-8">

          {filteredFarms.map((farm) => (
            <div
              key={farm._id}
              className="bg-white rounded-3xl shadow-lg hover:shadow-2xl transition overflow-hidden"
            >

              {/* Banner */}
              <div className="bg-gradient-to-r from-green-600 to-emerald-500 text-white p-6">

                <h2 className="text-2xl font-bold">
                  {farm.farmName}
                </h2>

                <p className="mt-2 flex items-center gap-2">
                  <MapPin size={18} />
                  {farm.location}
                </p>

              </div>

              {/* Body */}
              <div className="p-6 space-y-4">

                <div className="flex flex-wrap gap-2">

                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm flex items-center gap-1">
                    <Sprout size={15} />
                    {farm.cropType}
                  </span>

                  <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm flex items-center gap-1">
                    <Mountain size={15} />
                    {farm.soilType}
                  </span>

                </div>

                <div className="space-y-2">

                  <p className="flex items-center gap-2">
                    <Ruler size={18} />
                    {farm.area} Acres
                  </p>

                  <p className="flex items-center gap-2">
                    <User size={18} />
                    {farm.farmer?.name}
                  </p>

                </div>

                <div className="grid grid-cols-3 gap-3 pt-4">

                  <button
                    onClick={() =>
                      navigate(`/recommendation/${farm._id}`)
                    }
                    className="bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg flex justify-center"
                  >
                    <CloudSun size={18} />
                  </button>

                  <button
                    onClick={() =>
                      navigate(`/edit-farm/${farm._id}`)
                    }
                    className="bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-lg flex justify-center"
                  >
                    <Pencil size={18} />
                  </button>

                  <button
                    onClick={() => handleDelete(farm._id)}
                    className="bg-red-500 hover:bg-red-600 text-white py-2 rounded-lg flex justify-center"
                  >
                    <Trash2 size={18} />
                  </button>

                </div>

              </div>

            </div>
          ))}

        </div>
      )}
    </div>
  );
};

export default Farms;