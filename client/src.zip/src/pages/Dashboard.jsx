import { useEffect, useMemo, useState } from "react";
import DashboardLayout from "../layouts/DashboardLayout";
import { getWeather } from "../services/weatherService";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

import {
  CloudSun,
  Droplets,
  Tractor,
  Sprout,
  Wind,
  Thermometer,
  AlertTriangle,
  Power,
  CheckCircle2,
  Wrench,
  Gauge,
} from "lucide-react";

// ---- Mock data (swap for real API/DB data when ready) ------------------

const INITIAL_ZONES = [
  { id: "z1", name: "North Field", crop: "Wheat", moisture: 68, valveOn: true },
  { id: "z2", name: "East Terrace", crop: "Maize", moisture: 34, valveOn: false },
  { id: "z3", name: "South Plot", crop: "Vegetables", moisture: 52, valveOn: true },
];

const WATER_USAGE = [
  { day: "Mon", liters: 420 },
  { day: "Tue", liters: 380 },
  { day: "Wed", liters: 510 },
  { day: "Thu", liters: 460 },
  { day: "Fri", liters: 390 },
  { day: "Sat", liters: 340 },
  { day: "Sun", liters: 300 },
];

const EQUIPMENT = [
  { id: "e1", name: "Main Pump", status: "running" },
  { id: "e2", name: "Drip Valve A", status: "running" },
  { id: "e3", name: "Sprinkler B", status: "maintenance" },
];

// ---- Small presentational helpers --------------------------------------

const StatusBadge = ({ status }) => {
  const map = {
    running: { label: "Running", cls: "bg-emerald-50 text-emerald-700 ring-emerald-200", icon: CheckCircle2 },
    maintenance: { label: "Needs check", cls: "bg-amber-50 text-amber-700 ring-amber-200", icon: Wrench },
    off: { label: "Offline", cls: "bg-gray-100 text-gray-600 ring-gray-200", icon: Power },
  };
  const { label, cls, icon: Icon } = map[status] ?? map.off;
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full ring-1 ${cls}`}>
      <Icon size={13} />
      {label}
    </span>
  );
};

const MoistureGauge = ({ value }) => {
  const radius = 34;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;
  const color = value < 40 ? "#C17817" : value < 60 ? "#4A90A4" : "#40916C";

  return (
    <div className="relative w-20 h-20 shrink-0">
      <svg width="80" height="80" viewBox="0 0 80 80" className="-rotate-90">
        <circle cx="40" cy="40" r={radius} fill="none" stroke="#EDEAE1" strokeWidth="8" />
        <circle
          cx="40"
          cy="40"
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 700ms ease, stroke 700ms ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-sm font-bold" style={{ color }}>{value}%</span>
      </div>
    </div>
  );
};

const SkeletonLine = ({ w = "w-24" }) => (
  <div className={`h-4 ${w} bg-black/5 rounded animate-pulse`} />
);

// ---- Main component ------------------------------------------------------

const Dashboard = () => {
  const user = JSON.parse(localStorage.getItem("user"));

  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(true);
  const [zones, setZones] = useState(INITIAL_ZONES);
  const [now, setNow] = useState(new Date());

  const city = "Palampur";

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const response = await getWeather(city);
        if (response.success) setWeather(response.data);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };
    fetchWeather();
  }, []);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 60_000);
    return () => clearInterval(t);
  }, []);

  const toggleValve = (id) => {
    setZones((prev) =>
      prev.map((z) => (z.id === id ? { ...z, valveOn: !z.valveOn } : z))
    );
  };

  const lowMoistureZones = useMemo(
    () => zones.filter((z) => z.moisture < 40),
    [zones]
  );

  const greeting = useMemo(() => {
    const h = now.getHours();
    if (h < 12) return "Good morning";
    if (h < 17) return "Good afternoon";
    return "Good evening";
  }, [now]);

  return (
    <DashboardLayout>
      {/* Welcome Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[#1B4332] via-[#2D6A4F] to-[#40916C] text-white rounded-3xl p-8 shadow-xl mb-8">
        <div className="absolute -right-10 -top-10 w-56 h-56 rounded-full bg-white/5" />
        <div className="absolute right-16 bottom-0 w-24 h-24 rounded-full bg-white/5" />

        <div className="relative">
          <p className="text-sm uppercase tracking-wider text-white/70 font-medium mb-1">
            {now.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
          </p>
          <h1 className="text-3xl md:text-4xl font-bold flex items-center gap-2">
            🌱 Smart Irrigation Dashboard
          </h1>
          <p className="mt-3 text-lg">
            {greeting}, <strong>{user?.name ?? "Farmer"}</strong> 👋
          </p>
          <p className="opacity-90">
            Monitor your farms and irrigation from one place.
          </p>

          {lowMoistureZones.length > 0 && (
            <div className="mt-5 inline-flex items-center gap-2 bg-amber-400/20 text-amber-50 ring-1 ring-amber-300/40 rounded-xl px-4 py-2 text-sm">
              <AlertTriangle size={16} className="text-amber-200" />
              {lowMoistureZones.length === 1
                ? `${lowMoistureZones[0].name} is running low on moisture.`
                : `${lowMoistureZones.length} zones are running low on moisture.`}
            </div>
          )}
        </div>
      </div>

      {/* Top metric cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {/* Weather */}
        <div className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-2xl transition">
          <div className="flex justify-between items-center">
            <h2 className="font-bold text-gray-700">Weather</h2>
            <CloudSun className="text-yellow-500" size={32} />
          </div>

          {loading ? (
            <div className="mt-5 space-y-2">
              <SkeletonLine w="w-16" />
              <SkeletonLine w="w-28" />
            </div>
          ) : (
            <>
              <h1 className="text-4xl font-bold mt-4 text-[#2D6A4F]">
                {weather?.temperature}°C
              </h1>
              <p className="mt-3 text-gray-600">📍 {weather?.city}</p>
              <p className="text-gray-500">{weather?.description}</p>
            </>
          )}
        </div>

        {/* Humidity */}
        <div className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-2xl transition">
          <div className="flex justify-between items-center">
            <h2 className="font-bold text-gray-700">Humidity</h2>
            <Droplets className="text-[#4A90A4]" size={32} />
          </div>
          <h1 className="text-4xl font-bold mt-4 text-[#4A90A4]">
            {weather?.humidity ?? "--"}%
          </h1>
        </div>

        {/* Wind */}
        <div className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-2xl transition">
          <div className="flex justify-between items-center">
            <h2 className="font-bold text-gray-700">Wind Speed</h2>
            <Wind className="text-cyan-500" size={32} />
          </div>
          <h1 className="text-4xl font-bold mt-4 text-cyan-600">
            {weather?.windSpeed ?? "--"} m/s
          </h1>
        </div>

        {/* Farms */}
        <div className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-2xl transition">
          <div className="flex justify-between items-center">
            <h2 className="font-bold text-gray-700">Total Farms</h2>
            <Sprout className="text-[#2D6A4F]" size={32} />
          </div>
          <h1 className="text-4xl font-bold mt-4 text-[#2D6A4F]">1</h1>
        </div>
      </div>

      {/* Irrigation zones */}
      <div className="mt-8">
        <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
          <Gauge size={22} className="text-[#2D6A4F]" />
          Irrigation Zones
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {zones.map((zone) => (
            <div
              key={zone.id}
              className="bg-white rounded-2xl shadow-lg p-6 flex items-center gap-4 hover:shadow-2xl transition"
            >
              <MoistureGauge value={zone.moisture} />

              <div className="flex-1 min-w-0">
                <p className="font-bold text-gray-800 truncate">{zone.name}</p>
                <p className="text-sm text-gray-500 mb-3">{zone.crop}</p>

                <button
                  onClick={() => toggleValve(zone.id)}
                  className={`w-full inline-flex items-center justify-center gap-2 text-sm font-medium px-3 py-2 rounded-xl transition ${
                    zone.valveOn
                      ? "bg-[#2D6A4F] text-white hover:bg-[#1B4332]"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                >
                  <Power size={15} />
                  Valve {zone.valveOn ? "On" : "Off"}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Water usage + Equipment */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
        {/* Chart */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-lg p-6">
          <h2 className="text-lg font-bold text-gray-800 mb-1">Weekly Water Usage</h2>
          <p className="text-sm text-gray-500 mb-4">Liters consumed per day, all zones combined</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={WATER_USAGE} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#EDEAE1" />
                <XAxis dataKey="day" tick={{ fontSize: 12, fill: "#6b7280" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: "#6b7280" }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ borderRadius: 12, border: "1px solid #EDEAE1" }}
                  formatter={(v) => [`${v} L`, "Usage"]}
                />
                <Line
                  type="monotone"
                  dataKey="liters"
                  stroke="#2D6A4F"
                  strokeWidth={3}
                  dot={{ r: 4, fill: "#2D6A4F" }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Equipment */}
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <Tractor className="text-[#2D6A4F]" size={28} />
            <h2 className="text-lg font-bold text-gray-800">Equipment Status</h2>
          </div>

          <div className="space-y-3">
            {EQUIPMENT.map((eq) => (
              <div key={eq.id} className="flex items-center justify-between border border-gray-100 rounded-xl px-4 py-3">
                <span className="text-sm font-medium text-gray-700">{eq.name}</span>
                <StatusBadge status={eq.status} />
              </div>
            ))}
          </div>

          <p className="text-xs text-gray-400 mt-4">
            {EQUIPMENT.filter((e) => e.status === "running").length} of {EQUIPMENT.length} active
          </p>
        </div>
      </div>

      {/* Temperature detail */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center gap-3">
            <Thermometer className="text-red-500" size={30} />
            <h2 className="text-xl font-bold text-gray-800">Temperature Details</h2>
          </div>
          <p className="mt-6 text-gray-500">Current Temperature</p>
          <h1 className="text-5xl font-bold text-red-500 mt-2">
            {weather?.temperature ?? "--"}°C
          </h1>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center gap-3">
            <Droplets className="text-[#4A90A4]" size={30} />
            <h2 className="text-xl font-bold text-gray-800">Average Soil Moisture</h2>
          </div>
          <p className="mt-6 text-gray-500">Across all zones</p>
          <h1 className="text-5xl font-bold text-[#4A90A4] mt-2">
            {Math.round(zones.reduce((s, z) => s + z.moisture, 0) / zones.length)}%
          </h1>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;