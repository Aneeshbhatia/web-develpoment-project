import { useState } from "react";
import { registerUser } from "../services/authService";
import { useNavigate, Link } from "react-router-dom";
import {
  Mail,
  Lock,
  User,
  Eye,
  EyeOff,
  Leaf,
} from "lucide-react";

const Register = () => {
  const navigate = useNavigate();

  const [showPassword, setShowPassword] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "farmer",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const data = await registerUser(formData);

      alert(data.message);

      navigate("/login");
    } catch (error) {
      alert(error.response?.data?.message || "Registration Failed");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-700 via-emerald-600 to-green-500 flex">

      {/* Left */}
      <div className="hidden lg:flex lg:w-1/2 text-white flex-col justify-center px-20">

        <div className="flex items-center gap-4 mb-8">

          <div className="bg-white p-4 rounded-full">
            <Leaf className="text-green-700" size={40} />
          </div>

          <h1 className="text-5xl font-bold">
            Smart Irrigation
          </h1>

        </div>

        <h2 className="text-4xl font-bold leading-tight">
          Join The Future
          <br />
          Of Smart Farming
        </h2>

        <p className="mt-6 text-lg text-green-100 leading-8">
          Create your account to monitor weather,
          manage farms and receive intelligent irrigation
          recommendations.
        </p>

      </div>

      {/* Right */}
      <div className="flex-1 flex justify-center items-center p-10">

        <div className="bg-white rounded-3xl shadow-2xl p-10 w-full max-w-md">

          <h2 className="text-4xl font-bold text-center text-green-700">
            Create Account
          </h2>

          <p className="text-center text-gray-500 mt-3 mb-8">
            Start your farming journey
          </p>

          <form onSubmit={handleSubmit} className="space-y-5">

            {/* Name */}
            <div className="relative">

              <User
                size={20}
                className="absolute left-4 top-4 text-gray-400"
              />

              <input
                type="text"
                name="name"
                placeholder="Full Name"
                value={formData.name}
                onChange={handleChange}
                className="w-full border rounded-xl py-3 pl-12 pr-4 outline-none focus:ring-2 focus:ring-green-500"
                required
              />

            </div>

            {/* Email */}
            <div className="relative">

              <Mail
                size={20}
                className="absolute left-4 top-4 text-gray-400"
              />

              <input
                type="email"
                name="email"
                placeholder="Email Address"
                value={formData.email}
                onChange={handleChange}
                className="w-full border rounded-xl py-3 pl-12 pr-4 outline-none focus:ring-2 focus:ring-green-500"
                required
              />

            </div>

            {/* Password */}
            <div className="relative">

              <Lock
                size={20}
                className="absolute left-4 top-4 text-gray-400"
              />

              <input
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="Password"
                value={formData.password}
                onChange={handleChange}
                className="w-full border rounded-xl py-3 pl-12 pr-12 outline-none focus:ring-2 focus:ring-green-500"
                required
              />

              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-4 text-gray-500"
              >
                {showPassword ? (
                  <EyeOff size={20} />
                ) : (
                  <Eye size={20} />
                )}
              </button>

            </div>

            {/* Role */}
            <select
              name="role"
              value={formData.role}
              onChange={handleChange}
              className="w-full border rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-green-500"
            >
              <option value="farmer">Farmer</option>
              <option value="admin">Admin</option>
            </select>

            {/* Register Button */}
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-green-600 to-emerald-500 hover:from-green-700 hover:to-emerald-600 text-white py-3 rounded-xl text-lg font-semibold transition"
            >
              Create Account
            </button>

          </form>

          <p className="text-center mt-8 text-gray-600">
            Already have an account?

            <Link
              to="/login"
              className="ml-2 text-green-700 font-semibold"
            >
              Login
            </Link>
          </p>

        </div>

      </div>

    </div>
  );
};

export default Register;