import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";

const DashboardLayout = ({ children }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-100">

      {/* Top Navbar */}
      <Navbar />

      {/* Main Layout */}
      <div className="flex">

        {/* Sidebar */}
        <Sidebar />

        {/* Content */}
        <main className="flex-1 overflow-y-auto">

          <div className="p-8">

            {/* Breadcrumb */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 px-6 py-4 mb-8 flex items-center justify-between">

              <div>
                <h1 className="text-2xl font-bold text-gray-800">
                  🌱 Smart Irrigation System
                </h1>

                <p className="text-gray-500 text-sm mt-1">
                  Monitor your farms, weather, irrigation, and equipment from one dashboard.
                </p>
              </div>

              <div className="hidden md:flex items-center gap-3">

                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>

                <span className="text-green-700 font-semibold">
                  System Online
                </span>

              </div>

            </div>

            {/* Dynamic Page Content */}
            <div className="animate-fade-in">
              {children}
            </div>

          </div>

        </main>

      </div>

    </div>
  );
};

export default DashboardLayout;