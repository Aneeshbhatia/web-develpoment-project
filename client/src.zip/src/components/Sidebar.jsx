import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  Sprout,
  Tractor,
  ShoppingCart,
  Bell,
  User,
  LogOut,
  Leaf,
} from "lucide-react";

const Sidebar = () => {
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user"));

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    navigate("/login");
  };

  return (
    <aside className="w-72 min-h-screen bg-gradient-to-b from-green-700 to-emerald-600 text-white flex flex-col justify-between shadow-2xl">

      {/* Logo */}
      <div>

        <div className="flex items-center gap-3 p-6 border-b border-green-500">

          <div className="bg-white text-green-700 p-3 rounded-full">
            <Leaf size={28} />
          </div>

          <div>
            <h1 className="text-2xl font-bold">
              Smart Irrigation
            </h1>

            <p className="text-sm text-green-100">
              Farmer Dashboard
            </p>
          </div>

        </div>

        {/* Navigation */}
        <nav className="mt-8 flex flex-col gap-2 px-4">

          <NavLink
            to="/dashboard"
            className={({ isActive }) =>
              `flex items-center gap-3 p-3 rounded-xl transition ${
                isActive
                  ? "bg-white text-green-700 font-semibold shadow-lg"
                  : "hover:bg-green-600"
              }`
            }
          >
            <LayoutDashboard size={22} />
            Dashboard
          </NavLink>

          <NavLink
            to="/farms"
            className={({ isActive }) =>
              `flex items-center gap-3 p-3 rounded-xl transition ${
                isActive
                  ? "bg-white text-green-700 font-semibold shadow-lg"
                  : "hover:bg-green-600"
              }`
            }
          >
            <Sprout size={22} />
            My Farms
          </NavLink>

          <NavLink
            to="/equipment"
            className={({ isActive }) =>
              `flex items-center gap-3 p-3 rounded-xl transition ${
                isActive
                  ? "bg-white text-green-700 font-semibold shadow-lg"
                  : "hover:bg-green-600"
              }`
            }
          >
            <Tractor size={22} />
            Equipment
          </NavLink>

          <NavLink
            to="/marketplace"
            className={({ isActive }) =>
              `flex items-center gap-3 p-3 rounded-xl transition ${
                isActive
                  ? "bg-white text-green-700 font-semibold shadow-lg"
                  : "hover:bg-green-600"
              }`
            }
          >
            <ShoppingCart size={22} />
            Marketplace
          </NavLink>

          <NavLink
            to="/alerts"
            className={({ isActive }) =>
              `flex items-center gap-3 p-3 rounded-xl transition ${
                isActive
                  ? "bg-white text-green-700 font-semibold shadow-lg"
                  : "hover:bg-green-600"
              }`
            }
          >
            <Bell size={22} />
            Alerts
          </NavLink>

          <NavLink
            to="/profile"
            className={({ isActive }) =>
              `flex items-center gap-3 p-3 rounded-xl transition ${
                isActive
                  ? "bg-white text-green-700 font-semibold shadow-lg"
                  : "hover:bg-green-600"
              }`
            }
          >
            <User size={22} />
            Profile
          </NavLink>

        </nav>

      </div>

      {/* Bottom Section */}
      <div className="p-5 border-t border-green-500">

        <div className="mb-4">

          <h3 className="font-bold text-lg">
            {user?.name}
          </h3>

          <p className="text-green-100 text-sm">
            {user?.email}
          </p>

        </div>

        <button
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 bg-white text-red-600 py-3 rounded-xl hover:bg-red-100 transition font-semibold"
        >
          <LogOut size={20} />
          Logout
        </button>

      </div>

    </aside>
  );
};

export default Sidebar;