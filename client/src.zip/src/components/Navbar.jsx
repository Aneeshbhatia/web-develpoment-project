import { Bell, Search, Sun, UserCircle } from "lucide-react";

const Navbar = () => {
  const user = JSON.parse(localStorage.getItem("user"));

  return (
    <nav className="bg-white shadow-md border-b border-gray-200 sticky top-0 z-50">

      <div className="flex justify-between items-center px-8 py-4">

        {/* Logo */}
        <div>
          <h1 className="text-2xl font-bold text-green-700">
            🌱 Smart Irrigation
          </h1>

          <p className="text-sm text-gray-500">
            Precision Farming Dashboard
          </p>
        </div>

        {/* Search Bar */}
        <div className="hidden lg:flex items-center bg-gray-100 rounded-xl px-4 py-2 w-[380px]">

          <Search className="text-gray-500" size={20} />

          <input
            type="text"
            placeholder="Search farms, crops..."
            className="bg-transparent outline-none ml-3 w-full"
          />

        </div>

        {/* Right Section */}
        <div className="flex items-center gap-6">

          {/* Dark Mode (Coming Soon) */}
          <button className="bg-gray-100 hover:bg-gray-200 p-3 rounded-full transition">

            <Sun size={20} />

          </button>

          {/* Notifications */}
          <button className="relative bg-gray-100 hover:bg-gray-200 p-3 rounded-full transition">

            <Bell size={20} />

            <span className="absolute -top-1 -right-1 bg-red-500 w-4 h-4 rounded-full text-white text-[10px] flex items-center justify-center">
              2
            </span>

          </button>

          {/* User */}
          <div className="flex items-center gap-3">

            <UserCircle
              size={42}
              className="text-green-700"
            />

            <div className="hidden md:block">

              <h3 className="font-semibold">
                {user?.name}
              </h3>

              <p className="text-sm text-gray-500">
                {user?.role}
              </p>

            </div>

          </div>

        </div>

      </div>

    </nav>
  );
};

export default Navbar;