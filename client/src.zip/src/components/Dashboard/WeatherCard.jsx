import {
  CloudSun,
  Droplets,
  Wind,
  Thermometer,
} from "lucide-react";

const WeatherCard = ({ weather }) => {
  return (
    <div className="bg-white rounded-3xl shadow-lg p-6">

      <div className="flex justify-between items-center">

        <h2 className="text-2xl font-bold">
          Live Weather
        </h2>

        <CloudSun
          size={40}
          className="text-yellow-500"
        />

      </div>

      <div className="mt-6 space-y-4">

        <div className="flex justify-between">

          <span className="flex gap-2">
            <Thermometer />
            Temperature
          </span>

          <strong>
            {weather?.temperature}°C
          </strong>

        </div>

        <div className="flex justify-between">

          <span className="flex gap-2">
            <Droplets />
            Humidity
          </span>

          <strong>
            {weather?.humidity}%
          </strong>

        </div>

        <div className="flex justify-between">

          <span className="flex gap-2">
            <Wind />
            Wind
          </span>

          <strong>
            {weather?.windSpeed} m/s
          </strong>

        </div>

      </div>

    </div>
  );
};

export default WeatherCard;