import CountUp from "react-countup";
import { motion } from "framer-motion";

const StatsCard = ({
  title,
  value,
  suffix = "",
  icon,
  color,
}) => {
  return (
    <motion.div
      whileHover={{
        scale: 1.04,
      }}
      className="bg-white rounded-3xl shadow-lg p-6"
    >
      <div className="flex justify-between">

        <div>

          <p className="text-gray-500">
            {title}
          </p>

          <h2
            className={`text-4xl font-bold mt-3 ${color}`}
          >
            <CountUp
              end={value}
              duration={2}
            />

            {suffix}
          </h2>

        </div>

        <div className="text-5xl">
          {icon}
        </div>

      </div>
    </motion.div>
  );
};

export default StatsCard;