import { motion } from "framer-motion";
import { Leaf, CalendarDays, Sun } from "lucide-react";

const HeroSection = ({ user }) => {
  const today = new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const hour = new Date().getHours();

  const greeting =
    hour < 12
      ? "Good Morning"
      : hour < 17
      ? "Good Afternoon"
      : "Good Evening";

  return (
    <motion.div
      initial={{ opacity: 0, y: -25 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-green-700 via-emerald-600 to-green-500 p-8 shadow-2xl text-white"
    >
      <div className="absolute -top-10 -right-10 w-52 h-52 rounded-full bg-white/10 blur-2xl"></div>

      <div className="flex justify-between items-center">

        <div>

          <div className="flex items-center gap-3 mb-4">

            <Leaf size={45} />

            <h1 className="text-4xl font-bold">
              Smart Irrigation
            </h1>

          </div>

          <h2 className="text-3xl font-semibold">
            {greeting},{" "}
            <span className="text-yellow-300">
              {user?.name}
            </span>
            👋
          </h2>

          <p className="mt-3 text-green-100">
            Manage your farms with live weather,
            irrigation recommendations and analytics.
          </p>

          <div className="flex items-center gap-2 mt-5 text-green-100">

            <CalendarDays size={18} />

            {today}

          </div>

        </div>

        <div className="hidden lg:flex">

          <div className="bg-white/20 backdrop-blur-md rounded-full p-8">

            <Sun size={90} />

          </div>

        </div>

      </div>
    </motion.div>
  );
};

export default HeroSection;